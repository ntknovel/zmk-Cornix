#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dt-bindings/zmk/keys.h>
#include <zephyr/kernel.h>
#include <cornix_steno/engine.h>
#include <cornix_steno/quick.h>
#include <cornix_steno/roles.h>

extern uint32_t test_output_keys[];
extern size_t test_output_count;
void test_output_reset(void);
struct test_key_event { uint32_t key; bool state; int64_t ts; };
extern struct test_key_event test_key_events[];
extern size_t test_key_event_count;
void test_key_events_reset(void);
extern size_t test_quick_invoke_count;
extern enum cornix_steno_quick_slot test_quick_last_slot;
void test_quick_invoke_reset(void);
static int failures;

static void expect(const char *name, const uint32_t *keys, size_t count) {
    if (test_output_count != count ||
        (count && memcmp(test_output_keys, keys, count * sizeof(keys[0])))) {
        fprintf(stderr, "FAIL %s got=%zu expected=%zu\n", name, test_output_count, count);
        failures++;
    }
    test_output_reset();
}
static void expect_events(const char *name, uint32_t key, size_t taps) {
    if (test_key_event_count != taps * 2) {
        fprintf(stderr, "FAIL %s events=%zu expected=%zu\n", name,
                test_key_event_count, taps * 2); failures++;
    } else {
        for (size_t i = 0; i < taps; i++) {
            if (test_key_events[i*2].key != key || !test_key_events[i*2].state ||
                test_key_events[i*2+1].key != key || test_key_events[i*2+1].state) {
                fprintf(stderr, "FAIL %s bad tap %zu\n", name, i); failures++; break;
            }
        }
    }
    test_key_events_reset();
}
static int press(enum cornix_steno_role x, uint32_t p, int64_t t) {
    test_time_set(t); return cornix_steno_engine_role_pressed(x, p, t);
}
static int release(enum cornix_steno_role x, uint32_t p, int64_t t) {
    test_time_set(t); return cornix_steno_engine_role_released(x, p, t);
}

int main(void) {
    cornix_steno_engine_set_active(true);

    /* Normal release skew inside 50 ms keeps all keys. */
    press(CST_R_I_G,4,0); press(CST_R_V_A,44,8); press(CST_R_F_N,21,12);
    release(CST_R_I_G,4,30); release(CST_R_V_A,44,35); release(CST_R_F_N,21,40);
    const uint32_t gan[]={R,K,S}; expect("normal gan",gan,3);

    /* A wrong key released early is removed while the intended chord stays held. */
    press(CST_R_I_G,4,100); press(CST_R_V_A,44,108); press(CST_R_F_N,21,112);
    press(CST_R_I_NG,15,120); release(CST_R_I_NG,15,130);
    test_time_set(130); test_time_advance(55);
    release(CST_R_I_G,4,210); release(CST_R_V_A,44,220); release(CST_R_F_N,21,230);
    expect("early accidental removed",gan,3);

    /* Direct canonical abbreviation: 그런. */
    press(CST_R_I_G,4,300); press(CST_R_F_R,19,310);
    release(CST_R_I_G,4,330); test_time_advance(55); release(CST_R_F_R,19,400);
    const uint32_t geureon[]={R,M,F,J,S}; expect("direct abbreviation prefix protected",geureon,5);

    /* ABBR anchor held while consonants are tapped sequentially: 그럼. */
    press(CST_R_ABBR_L,12,500); press(CST_R_I_G,4,600); release(CST_R_I_G,4,620);
    test_time_advance(55); press(CST_R_F_R,19,690); release(CST_R_F_R,19,710);
    release(CST_R_ABBR_L,12,730);
    const uint32_t geureom[]={R,M,F,J,A}; expect("held abbreviation anchor",geureom,5);

    /* Quick M0 remains GUI-editable and invokes the macro dispatcher. */
    test_quick_invoke_reset();
    press(CST_R_ABBR_L,12,800); press(CST_R_V_EU,42,810);
    release(CST_R_V_EU,42,830); release(CST_R_ABBR_L,12,840);
    if (test_quick_invoke_count != 1 || test_quick_last_slot != CST_QUICK_M0) {
        fprintf(stderr,"FAIL quick M0 count=%zu slot=%d\n",test_quick_invoke_count,
                test_quick_last_slot); failures++;
    }
    expect("quick no dictionary queue",NULL,0);

    /* ABBR + same-side double repeats plain horizontal movement. */
    test_key_events_reset();
    press(CST_R_ABBR_L,12,900); press(CST_R_I_DOUBLE,29,910); release(CST_R_I_DOUBLE,29,920);
    press(CST_R_I_DOUBLE,29,930); release(CST_R_I_DOUBLE,29,940); release(CST_R_ABBR_L,12,950);
    expect_events("ABBR-L repeated left",LEFT,2);

    press(CST_R_ABBR_R,23,1000); press(CST_R_F_DOUBLE,32,1010); release(CST_R_F_DOUBLE,32,1020);
    press(CST_R_F_DOUBLE,32,1030); release(CST_R_F_DOUBLE,32,1040); release(CST_R_ABBR_R,23,1050);
    expect_events("ABBR-R repeated right",RIGHT,2);

    /* SYMBOL + same-side double repeats Shift selection movement. */
    press(CST_R_SYMBOL_L,40,1100); press(CST_R_I_DOUBLE,29,1110); release(CST_R_I_DOUBLE,29,1120);
    press(CST_R_I_DOUBLE,29,1130); release(CST_R_I_DOUBLE,29,1140); release(CST_R_SYMBOL_L,40,1150);
    expect_events("SYMBOL-L repeated select left",LS(LEFT),2);

    press(CST_R_SYMBOL_R,47,1200); press(CST_R_F_DOUBLE,32,1210); release(CST_R_F_DOUBLE,32,1220);
    press(CST_R_F_DOUBLE,32,1230); release(CST_R_F_DOUBLE,32,1240); release(CST_R_SYMBOL_R,47,1250);
    expect_events("SYMBOL-R repeated select right",LS(RIGHT),2);

    /* Original logical 그러기 mask survives the new same-finger physical layout. */
    test_key_events_reset();
    press(CST_R_ABBR_L,12,1300); press(CST_R_I_G,4,1310); press(CST_R_I_R,16,1320);
    press(CST_R_I_DOUBLE,29,1330); release(CST_R_I_DOUBLE,29,1340);
    release(CST_R_I_G,4,1350); release(CST_R_I_R,16,1360); release(CST_R_ABBR_L,12,1370);
    const uint32_t geureogi[]={R,M,F,J,R,L}; expect("abbr exact survives nav",geureogi,6);
    expect_events("abbr exact no arrow",LEFT,0);

    /* Every jamo role is its own correction key on a solo 150 ms hold-release. */
    press(CST_R_I_G,4,1400); release(CST_R_I_G,4,1550);
    const uint32_t solo_g[]={R}; expect("solo-hold initial giyeok",solo_g,1);

    press(CST_R_F_N,21,1600); release(CST_R_F_N,21,1755);
    const uint32_t solo_n[]={S}; expect("solo-hold final nieun",solo_n,1);

    press(CST_R_V_I,45,1800); release(CST_R_V_I,45,1950);
    const uint32_t solo_i[]={L}; expect("solo-hold vowel i",solo_i,1);

    /* Once another STENO role participates, even a long hold is a normal stroke. */
    press(CST_R_I_G,4,2000); press(CST_R_V_A,44,2050);
    release(CST_R_V_A,44,2070); release(CST_R_I_G,4,2200);
    const uint32_t ga[]={R,K}; expect("multi-key overrides solo hold",ga,2);

    /* Physical ㅣ+I/J/K/L navigation remains immediate. */
    test_key_events_reset();
    press(CST_R_V_I,45,1600); press(CST_R_F_D,8,1610); release(CST_R_F_D,8,1630);
    release(CST_R_V_I,45,1640);
    if (test_key_event_count != 2 || test_key_events[0].key != UP ||
        !test_key_events[0].state || test_key_events[1].key != UP ||
        test_key_events[1].state) {
        fprintf(stderr,"FAIL physical I+I navigation events=%zu\n",test_key_event_count); failures++;
    }
    test_key_events_reset(); expect("physical nav no text",NULL,0);

    /* Legal final cluster rolling restores an early first final inside 90 ms. */
    press(CST_R_I_G,4,1700); press(CST_R_V_A,44,1710); press(CST_R_F_R,19,1720);
    release(CST_R_F_R,19,1730); test_time_advance(55);
    press(CST_R_F_G,7,1800); release(CST_R_F_G,7,1810);
    release(CST_R_I_G,4,1820); release(CST_R_V_A,44,1830);
    const uint32_t dalk[]={R,K,F,R}; expect("final roll rieul-giyeok",dalk,4);

    /* Original logical right-tail exact remains protected: 이었다. */
    press(CST_R_F_D,8,1900); press(CST_R_F_DOUBLE,32,1910); release(CST_R_F_DOUBLE,32,1920);
    test_time_advance(55); press(CST_R_F_NG,20,1990); release(CST_R_F_NG,20,2000);
    release(CST_R_F_D,8,2010);
    const uint32_t ieotda[]={D,L,D,J,LS(T),E,K}; expect("tail rolling ieotda",ieotda,7);

    press(CST_R_I_G,4,2100); cornix_steno_engine_set_active(false);
    release(CST_R_I_G,4,2120); expect("mode exit cancel",NULL,0);

    if (failures) return EXIT_FAILURE;
    puts("Cornix STENO v2.1.1 solo-hold direct-jamo engine tests: PASS");
    return EXIT_SUCCESS;
}
